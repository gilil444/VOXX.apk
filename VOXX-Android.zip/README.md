# VOXX Android

Starter Android profile app:
- App name: VOXX
- Profile handle: baaaelzz
- Sky-blue and white theme
- Profile avatar placeholder marked D for Denia (Wuthering Waves)
- Identity sections: full name, age, birth date (day/month/year), address, and school

The identity fields are placeholders ("Belum diisi"). No personal information has been prefilled.
The Denia avatar is a placeholder; add the exact character artwork you want to use in the Android project.

## Build APK
Open this folder in Android Studio, wait for Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
