package com.voxx.profile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int deep = 0xFF145477, ink = 0xFF16384A;
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void detail(LinearLayout parent, String label, String value) {
        LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(15, 12, 15, 12); item.setBackground(shape(0xFFF2FAFE, 16));
        TextView l = txt(label.toUpperCase(), 10, 0xFF438DB1, true);
        TextView v = txt(value, 15, ink, false); v.setPadding(0, 5, 0, 0);
        item.addView(l); item.addView(v);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 9;
        parent.addView(item, p);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF64C8F5); getWindow().setNavigationBarColor(deep);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(22, 28, 22, 26);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xFFBCEBFF, 0xFFF5FCFF}));
        scroll.addView(root);

        TextView brand = txt("VOXX", 30, deep, true); brand.setLetterSpacing(.18f); root.addView(brand);
        TextView tagline = txt("YOUR SPACE. YOUR IDENTITY.", 11, deep, true);
        tagline.setPadding(0, 4, 0, 22); root.addView(tagline);

        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 22, 18, 20); card.setBackground(shape(0xFFFFFFFF, 25)); card.setElevation(7);
        card.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView avatar = txt("D", 52, -1, true); avatar.setGravity(Gravity.CENTER);
        avatar.setBackground(shape(0xFF59BCEB, 100));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(112,112); ap.bottomMargin=10; card.addView(avatar, ap);
        TextView note = txt("DENIA • WUTHERING WAVES", 10, 0xFF3C8FB6, true); note.setPadding(0,0,0,9); card.addView(note);
        card.addView(txt("baaaelzz", 27, ink, true));
        TextView sub = txt("Personal identity profile", 13, 0xFF6B8795, false);
        sub.setPadding(0,4,0,20); card.addView(sub);

        View divider = new View(this); divider.setBackgroundColor(0xFFE2F4FC);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,1); dp.bottomMargin=16; card.addView(divider,dp);
        TextView heading = txt("IDENTITAS", 13, deep, true); heading.setLetterSpacing(.1f);
        heading.setPadding(0,0,0,12); card.addView(heading);

        detail(card, "Nama lengkap", "Belum diisi");
        detail(card, "Umur", "Belum diisi");
        detail(card, "Tanggal lahir", "Tanggal / Bulan / Tahun");
        detail(card, "Alamat", "Belum diisi");
        detail(card, "Sekolah", "Belum diisi");

        TextView privacy = txt("Isi data identitas hanya jika nyaman. Jangan masukkan alamat lengkap atau data pribadi sensitif jika profil akan dibagikan ke publik.", 11, 0xFF718B97, false);
        privacy.setPadding(2, 8, 2, 0); card.addView(privacy);
        root.addView(card, new LinearLayout.LayoutParams(-1,-2));

        TextView footer = txt("VOXX  •  SKY BLUE EDITION", 11, 0xFF4F9FC2, true);
        footer.setPadding(0,20,0,0); root.addView(footer);
        setContentView(scroll);
    }
}